class Ad_data:
    CHROME_EXECUTABLE_PATH = r'C:\chromedriver\chromedriver.exe'
    CHROME_PROFILE = 'C:\\Users\\rak13\\AppData\\Local\\Google\\Chrome\\User Data\\Profile 1'
    LINKS_FILE_NAME = 'linksFile.txt'
    BASE_URL = "https://bostonmais.com/adverts/add/"

    if BASE_URL in ["https://diariodelhuila.com/clasificados/add/", "https://bostonmais.com/adverts/add/"]:
        SLEEP = 0.5
    else:
        SLEEP = 0
    IMAGE = 1
    EMAIL = "email@email.com"
    PASSWORD = 'PASSWORD'
    CONTACT_PERSON = 'James'
    VENUE = 'venue'
    ADDRESS1 = 'address1'
    ADDRESS2 = 'address2'
    CITY = 'CITY'
    STATE = 'state'
    ZIP = '5555'
    PHONE = '01399393434'
    TEAMS = {
        1: {
            'TeamA': 'Brazil',
            'TeamB': 'Argentina',
            'LINK': 'https://source.unsplash.com',
            'LINK_TEXT': "WATCH HERE ▶️▶️"
        },
        2:{
            'TeamA':'PSG',
            'TeamB':'Bercelona',
            'LINK' : 'https://source.unsplash.com',
            'LINK_TEXT':"WATCH HERE ▶️▶️"
        }
    }

    TITLES = {
        1: '[HD] [TeamA] vs [TeamB] Live Stream',
        # 2: '[ONLINE] [TeamB] vs [TeamA] Live Stream',
        # 3: '[NCAA] [TeamA] vs [TeamB] Live Online',
        # 4: '[WATCH] [TeamB] vs [TeamA] Live Online',
        # 5: '[LIVE] [TeamA] vs [TeamB] Live Free',
        # 6: '[ITV] [TeamB] vs [TeamA] Live Free',
        # 7: '[STREAMING] [TeamA] vs [TeamB] Live',
        # 8: '[FREE]>>> [TeamB] vs [TeamA] Live',
        # 9: '[HDQ] [TeamA] vs [TeamB] 2021 Live',
        # 10: '[GAME]>>> [TeamB] vs [TeamA] 2021 Live',
    }

    DESCRIPTION = {
        1: f'''<h5>[TeamA] vs [TeamB] 2 Live kick-off time, TV channel, live stream info and team ne</h5>
    <h6>[TeamA] vs [TeamB] Live free live stream and how to watch the NFL Week</h6>
    <h6>Live NFL Week 2: [TeamA] vs [TeamB] Live as McKenzie earns rare start at <h5>
    <center><h1><a href=[LINK]>[LINK_TEXT]</a></h1></center>

    <a href=[LINK]><img width='800' height="500"  src='https://source.unsplash.com/900x900/?Football'></a>
    <h1 ><a href=[LINK]>[LINK_TEXT]</a></h1>


    <p>Lavonte David was fined for this non-called penalty so the [TeamA] vs [TeamB] Live will feel like justice has been served, but this potentially swung the game (obviously we are using some hindsight to come to that conclusion). How is that fair?</p>



    <h2>A quick note regarding the “third-and-long” measure as a litmus test for the franchise-iness of a quarterback: In 2019, the Cowboys led the [TeamA] vs [TeamB] Live in third-and-6+ conversion rate (34.5%). In 2020, with Dak Prescott missing two thirds of the season, they fell to dead last (18.8%). In last Thursday’s opener, they went a respectable 2-for-6 (33.3%) against the Bucs.</h2>

    <h2>Here's a List 1</h2>

    <ul>
        <li><h2>Scores</h2></li>
        <li><h2>Scores</h2></li>
        <li><h2>Scores</h2></li>
    </ul>

    <h3><b>in 2015 and earning a Pro Bowl nod, Eifert suffered through three injury-plagued seasons before bouncing back and playing 16 games in 2019. He signed a two-year,</b></h3>

    <p> free-agent deal with the [TeamA] the following offseason.
    It’s what happened on the third down play, rather after it, that many people were upset by. Dak Prescott’s pass should have been intercepted by Lavonte David and David</p>
    <h2><b>Here's a List 2 </b></h2>

    <ol>
        <li><h2>Scores</h2></li>
        <li><h2>Scores</h2></li>

    </ol>

    <h3> free-agent deal with the [TeamA] the following offseason.
    It’s what happened on the third down play, rather after it, that many people were upse</h3>

    <p>ree-agent deal with the [TeamA] the following offseason.
    It’s what happened on the third down play, rather after it, that many people were upset by. Dak Prescott’s pass should have been intercepted by Lavonte David and David was so upset that it wasn’t that he slammed his helmet down on the field in frustration. That is a clear and obvious unsportsmanlike conduct penalty.</p>
    <a href=[LINK]><img width='800' height="500" src='https://source.unsplash.com/900x900/?Sports,soccer"'></a>

    <p>
    The Minnesota Vikings signed running back Ameer Abdullah to the active roster. Safety Myles Dorn and quarterback Sean Mannion have been elevated to the active roster for Sunday's game.
    Last week I tried to focus on games where the mismatch in the trenches looked the most acute and this is another example. Zach Wilson is going to see some looks that will confuse him. The chasm in experience and accomplishment between the Denver staff and the Jaguars staff is massive at this point.
    </p>

    <h4>
     Belichick will have the Broncos prepared as if this is a playoff game because he knows starting 0-2 and, in particular, starting 0-2 against divisional opponents that he feels he should beat, could end up damning their season.
    </h4>
    <h2>Here's a List</h2>
    <ul>
        <li><h2>Performance</h2></li>
        <li><h2>Performance</h2></li>
        <li><h2>Performance</h2></li>

    </ul>

    <p>Pittsburgh Steelers receiver Chase Claypool was fined $8,354 for unsportsmanlike conduct in an early dustup against the Bills, Pelissero reported.
    MINNESOTA VIKINGS at ARIZONA CARDINALS: The Cardinals are a bigger threat to the Eagles in the NFC than Kirk Cousins’s Vikings are. Root for the Vikings.</p>

    <p>
    Dr. Allen Sills, the league’s chief medical officer, said almost all cases across have been the Delta variant. He said vaccinated individuals have had very mild upper respiratory illness, shorter duration. Sills also said none of the players who’ve tested positive required hospitalization.
    You can boil down why the Cowboys lost the game to a few moments. Some people would look to the short missed field goal and extra point from Greg Zuerlein. Others might talk about the quick Antonio Brown touchdown at the end of the first half. But one moment it seems just about everybody would focus on came on the Cowboys’ penultimate possession of the first half.

    </p>
    <p>
    \"The biggest factor was, I had to think about my career,\" Brown said after agreeing to terms, per Pro Football Talk's Myles Simmons. \"I actually turned down more money to come here. I felt like it was the best decision for my career, so I had to put everything else aside and had to try to decide what would make me happy at the end of the day.\"
    KANSAS CITY CHIEFS at BALTIMORE RAVENS: We know the Chiefs will make the playoffs even if they lose this game. But things won’t be looking good for Baltimore if they drop to 0-2. Better for the Ravens to push a
    </p>

    <p>
    playoff spot that could keep Miami and/or Indy out of the mix. Root for the Ravens.
    Even when the Ravens roster has been at full strength in recent years, the Chiefs have been their Kryptonite. Last year in prime time, Kansas City came into Baltimore and whacked the Ravens for four quarters. That, of course, was without fans and it will be crazy in Baltimore on Sunday night, but this is also not the Ravens team we have become accustomed to. </p>

    <p>
    "The biggest factor was, I had to think about my career,\" Brown said after agreeing to terms, per Pro Football Talk's Myles Simmons. \"I actually turned down more money to come here. I felt like it was the best decision for my career, so I had to put everything else aside and had to try to decide what would make me happy at the end of the day.\"
    That's Will Brinson, highlightingddkfkfdkdfdf Buffalo's defense as a big reason he likes the Bills to bounce back in a big way against their AFC East rivals. Check out Brinson's full rundown of Week 2 picks and best bets, which includes some free props, for more of his projections.
    </p>
    ''',

        #         2: '''NFL Week 2 – [TeamA] vs [TeamB] Live Preview & Prediction
        # [TeamA] vs [TeamB] Live kick-off time, TV channel, live stream info and team news
        # [TeamA] vs [TeamB] Live free live stream and how to watch the NFL Week 2
        # [LINK]
        # Live NFL Week 2: [TeamA] vs [TeamB] Live as McKenzie earns rare start at 10
        # Lavonte David was fined for this non-called penalty so the [TeamA] vs [TeamB] Live will feel like justice has been served, but this potentially swung the game (obviously we are using some hindsight to come to that conclusion). How is that fair?
        # 4. A quick note regarding the “third-and-long” measure as a litmus test for the franchise-iness of a quarterback: In 2019, the Cowboys led the [TeamA] vs [TeamB] Live in third-and-6+ conversion rate (34.5%). In 2020, with Dak Prescott missing two thirds of the season, they fell to dead last (18.8%). In last Thursday’s opener, they went a respectable 2-for-6 (33.3%) against the Bucs.
        # Potential fits likely dwindled based on Sherman being charged in July with five misdemeanors of driving under the i[TeamA] vs [TeamB] Liveuence, reckless endangerment of roadway workers, criminal trespass in the second degree (domestic violence designation), resisting arrest and malicious mischief in the third degree (domestic violence designation).
        # After posting 13 touchdown catches in 2015 and earning a Pro Bowl nod, Eifert suffered through three injury-plagued seasons before bouncing back and playing 16 games in 2019. He signed a two-year, free-agent deal with the [TeamA] the following offseason.
        # It’s what happened on the third down play, rather after it, that many people were upset by. Dak Prescott’s pass should have been intercepted by Lavonte David and David was so upset that it wasn’t that he slammed his helmet down on the field in frustration. That is a clear and obvious unsportsmanlike conduct penalty.
        # The Minnesota Vikings signed running back Ameer Abdullah to the active roster. Safety Myles Dorn and quarterback Sean Mannion have been elevated to the active roster for Sunday's game.
        # Last week I tried to focus on games where the mismatch in the trenches looked the most acute and this is another example. Zach Wilson is going to see some looks that will confuse him. The chasm in experience and accomplishment between the Denver staff and the Jaguars staff is massive at this point. Belichick will have the Broncos prepared as if this is a playoff game because he knows starting 0-2 and, in particular, starting 0-2 against divisional opponents that he feels he should beat, could end up damning their season.
        # Pittsburgh Steelers receiver Chase Claypool was fined $8,354 for unsportsmanlike conduct in an early dustup against the Bills, Pelissero reported.
        # MINNESOTA VIKINGS at ARIZONA CARDINALS: The Cardinals are a bigger threat to the Eagles in the NFC than Kirk Cousins’s Vikings are. Root for the Vikings.
        # Dr. Allen Sills, the league’s chief medical officer, said almost all cases across have been the Delta variant. He said vaccinated individuals have had very mild upper respiratory illness, shorter duration. Sills also said none of the players who’ve tested positive required hospitalization.
        # You can boil down why the Cowboys lost the game to a few moments. Some people would look to the short missed field goal and extra point from Greg Zuerlein. Others might talk about the quick Antonio Brown touchdown at the end of the first half. But one moment it seems just about everybody would focus on came on the Cowboys’ penultimate possession of the first half.
        # \"The biggest factor was, I had to think about my career,\" Brown said after agreeing to terms, per Pro Football Talk's Myles Simmons. \"I actually turned down more money to come here. I felt like it was the best decision for my career, so I had to put everything else aside and had to try to decide what would make me happy at the end of the day.\"
        # KANSAS CITY CHIEFS at BALTIMORE RAVENS: We know the Chiefs will make the playoffs even if they lose this game. But things won’t be looking good for Baltimore if they drop to 0-2. Better for the Ravens to push a playoff spot that could keep Miami and/or Indy out of the mix. Root for the Ravens.
        # Even when the Ravens roster has been at full strength in recent years, the Chiefs have been their Kryptonite. Last year in prime time, Kansas City came into Baltimore and whacked the Ravens for four quarters. That, of course, was without fans and it will be crazy in Baltimore on Sunday night, but this is also not the Ravens team we have become accustomed to.
        # \"The biggest factor was, I had to think about my career,\" Brown said after agreeing to terms, per Pro Football Talk's Myles Simmons. \"I actually turned down more money to come here. I felt like it was the best decision for my career, so I had to put everything else aside and had to try to decide what would make me happy at the end of the day.\"
        # That's Will Brinson, highlightingddkfkfdkdfdf Buffalo's defense as a big reason he likes the Bills to bounce back in a big way against their AFC East rivals. Check out Brinson's full rundown of Week 2 picks and best bets, which includes some free props, for more of his projections.
        # '''
    }




